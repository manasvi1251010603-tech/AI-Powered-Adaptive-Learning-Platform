"""FastAPI application entrypoint.

This file only wires things together (settings, logging, middleware,
error handlers, routers) — no business logic lives here, per the
project's coding standards. Feature routers are added to
app/api/router.py in later tasks, not here.
"""

import uuid

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from app.api.router import api_router
from app.core.config import get_settings
from app.core.errors import register_exception_handlers
from app.core.logging import configure_logging
from app.db.session import check_database_connection

settings = get_settings()
configure_logging()

app = FastAPI(
    title="AI-Powered Adaptive Learning Platform API",
    description=(
        "Backend for the AI-Powered Adaptive Learning Platform. "
        "This is the foundation layer only — feature endpoints are "
        "added incrementally in later tasks."
    ),
    version="0.1.0",
)

# --- CORS ---
# Origins come from BACKEND_CORS_ORIGINS (comma-separated). Never falls
# back to "*" — see .env.example for the local frontend default.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- Request ID ---
# Every response gets a request ID, both as a header and available to
# error handlers (app/core/errors.py) so error payloads can include it,
# matching the request_id field in the API's standard error format.
@app.middleware("http")
async def add_request_id(request: Request, call_next) -> Response:
    request.state.request_id = str(uuid.uuid4())
    response = await call_next(request)
    response.headers["X-Request-ID"] = request.state.request_id
    return response


# --- Centralized error handling ---
register_exception_handlers(app)

# --- Versioned API router (empty for now, see app/api/router.py) ---
app.include_router(api_router, prefix="/api/v1")


# --- Health endpoints ---
# These live outside /api/v1, at the application root, so they work as
# conventional infrastructure health checks (load balancers, container
# platforms) without needing to know about API versioning.


class HealthResponse(BaseModel):
    status: str


class DependencyStatus(BaseModel):
    database: str


class ReadinessResponse(BaseModel):
    status: str
    dependencies: DependencyStatus


@app.get("/health", tags=["health"], response_model=HealthResponse)
async def health() -> HealthResponse:
    """Liveness check: is the process up and able to respond at all."""
    return HealthResponse(status="ok")


@app.get("/ready", tags=["health"], response_model=ReadinessResponse)
async def ready(response: Response) -> ReadinessResponse:
    """Readiness check: are required dependencies available.

    For this foundation layer, that means PostgreSQL only (Redis and
    other dependencies aren't wired up yet, and will be added to this
    check when they're introduced in later tasks).
    """
    database_status = check_database_connection()
    is_ready = database_status == "ok"

    response.status_code = 200 if is_ready else 503

    return ReadinessResponse(
        status="ready" if is_ready else "not_ready",
        dependencies=DependencyStatus(database=database_status),
    )
