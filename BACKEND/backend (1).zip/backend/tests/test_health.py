"""Tests for the foundation layer: app import and the health endpoint.

Deliberately does not test /ready against a real database — that would
make the test suite depend on a running PostgreSQL instance. /ready is
exercised manually (see README.md) and will get proper test coverage
(with a test database or a mocked connection) once the database layer
has real models to test against.
"""

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_app_initializes_without_importing_future_feature_modules() -> None:
    """The app object must import and construct cleanly.

    This module only imports app.main, which only imports the
    foundation-layer modules (core/, db/, api/router.py). If a future
    change accidentally imports an unbuilt feature module at startup,
    this import would fail loudly here.
    """
    assert app.title == "AI-Powered Adaptive Learning Platform API"


def test_health_returns_200_and_status_ok() -> None:
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_ready_returns_a_dependencies_object() -> None:
    """/ready should always report a structured dependency status.

    Status code varies with whether DATABASE_URL is configured/reachable
    in the environment running the tests, so this only asserts on
    response shape, not on a specific "ready" outcome.
    """
    response = client.get("/ready")

    assert response.status_code in (200, 503)
    body = response.json()
    assert body["status"] in ("ready", "not_ready")
    assert "database" in body["dependencies"]
    assert body["dependencies"]["database"] in ("ok", "error", "not_configured")


def test_ready_status_code_matches_reported_database_status() -> None:
    """200 must mean database=ok; anything else must be a 503, never a 200
    with a hidden failure. Also guards against the response-model bug
    (FastAPIError: Invalid args for response field) regressing — the
    endpoint must return a real, schema-validated body, not just any dict.
    """
    response = client.get("/ready")
    body = response.json()

    if body["dependencies"]["database"] == "ok":
        assert body["status"] == "ready"
        assert response.status_code == 200
    else:
        assert body["status"] == "not_ready"
        assert response.status_code == 503


def test_openapi_schema_generates_without_error() -> None:
    """Guards against response-model schema-generation errors (the root
    cause of the original /ready startup crash) resurfacing silently —
    if FastAPI can't build a valid response field for an endpoint, this
    fails the same way the app would fail to start.
    """
    schema = app.openapi()
    assert "/ready" in schema["paths"]
    assert "/health" in schema["paths"]
