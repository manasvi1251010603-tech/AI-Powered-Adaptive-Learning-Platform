# Backend — AI-Powered Adaptive Learning Platform

## 1. What this is

This is the **FastAPI backend** for the AI-Powered Adaptive Learning
Platform. This README currently describes the **foundation layer
only**: a clean, runnable API with configuration, a database
connection, migrations, health checks, logging, and error handling —
and nothing else yet.

No feature endpoints exist yet (no auth, no users, no assessments, no
AI, no video). Those are built incrementally in later tasks, on top of
this foundation. See [`docs/TECH_STACK.md`](../docs/TECH_STACK.md) for
the full technology decisions and reasoning, and [`docs/API_SPECIFICATION.md`](../docs/API_SPECIFICATION.md)
for the eventual full API contract.

---

## 2. Create the Python environment

You need **Python 3.12+** installed. Then, from the `backend/` directory:

```bash
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
```

You'll know it worked if your terminal prompt now starts with `(.venv)`.

---

## 3. Install dependencies

```bash
pip install --upgrade pip
pip install -e ".[dev]"
```

This installs:
- **Runtime:** FastAPI, Uvicorn, Pydantic, Pydantic Settings, SQLAlchemy, Alembic, psycopg (PostgreSQL driver)
- **Dev/test:** Pytest, HTTPX, Ruff, Black

(Nothing else — Redis, JWT, OpenAI, and storage libraries are added in
later tasks when those features are actually built.)

---

## 4. Configure your `.env`

Copy the example file and fill in real local values:

```bash
cp .env.example .env
```

Open `.env` and set at least:

```
DATABASE_URL=postgresql+psycopg://<user>:<password>@localhost:5432/<database>
```

You'll need a running local PostgreSQL instance and a database created
for this project. If you don't have Postgres installed locally, the
quickest option is Docker:

```bash
docker run --name learning-platform-db \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=learning_platform \
  -p 5432:5432 \
  -d postgres:16
```

...which matches a `.env` value of:

```
DATABASE_URL=postgresql+psycopg://postgres:postgres@localhost:5432/learning_platform
```

The other variables in `.env.example` (`REDIS_URL`, `JWT_SECRET_KEY`,
`OPENAI_API_KEY`, `STORAGE_*`) are placeholders for later tasks — you
can leave them blank for now.

---

## 5. Run the FastAPI server

```bash
uvicorn app.main:app --reload --reload-dir app --port 8000
```

`--reload-dir app` tells Uvicorn's auto-reloader to only watch the
`app/` source directory. Without it, Uvicorn watches the entire
current working directory recursively — including `.venv/` — so every
package installed there is treated as a "file change," which shows up
as WatchFiles repeatedly triggering reloads for paths under
`.venv\Lib\site-packages`. This isn't a bug in the code, just a
missing flag; nothing in `app/` needed to change for it.

- API root: http://localhost:8000
- Interactive docs (Swagger UI): http://localhost:8000/docs
- OpenAPI schema: http://localhost:8000/openapi.json

The server will start even without a configured/running database —
`GET /health` will work regardless, and `GET /ready` will correctly
report that the database is unavailable.

---

## 6. Run tests

```bash
pytest
```

This runs `tests/test_health.py`, which checks that:
- the app imports and initializes without needing any future feature module,
- `GET /health` returns `200` with `{"status": "ok"}`,
- `GET /ready` returns a well-formed response either way (it doesn't require a database to be running to pass).

---

## 7. Run Alembic

Alembic is configured to read `DATABASE_URL` from your `.env` (via
`app.core.config`), so there's nothing to configure separately in
`alembic.ini`.

Check that Alembic can read your configuration and connect:

```bash
alembic current
```

- If this prints `(nothing shown / no current revision)` with no
  error, Alembic is correctly configured and connected to your
  database — as expected, since no migrations exist yet.
- If it errors, it's almost always one of:
  - `DATABASE_URL` isn't set in `.env`
  - PostgreSQL isn't running
  - the database named in `DATABASE_URL` doesn't exist yet

**Do not** run `alembic revision --autogenerate` yet — there are no
application models to generate a migration from. That happens in the
task that introduces the first models.

---

## 8. Check `/health`

With the server running (step 5):

```bash
curl http://localhost:8000/health
```

Expected:

```json
{"status": "ok"}
```

And to check readiness (requires a running, reachable PostgreSQL per your `.env`):

```bash
curl http://localhost:8000/ready
```

Expected when the database is reachable:

```json
{"status": "ready", "dependencies": {"database": "ok"}}
```

If the database isn't configured or isn't reachable, this returns
HTTP `503` with `"status": "not_ready"` and `"database": "not_configured"`
or `"database": "error"` — it will never silently report success.

---

## Project structure

```
backend/
├── app/
│   ├── main.py            # FastAPI app, middleware, health endpoints
│   ├── core/
│   │   ├── config.py       # Typed settings (Pydantic Settings)
│   │   ├── logging.py      # Basic logging configuration
│   │   └── errors.py       # Centralized error handling
│   ├── db/
│   │   ├── base.py         # SQLAlchemy declarative base (no models yet)
│   │   └── session.py      # Engine, session factory, DB health check
│   └── api/
│       └── router.py       # Empty /api/v1 router, ready for future endpoints
├── alembic/                # Migrations (none yet — no models exist)
├── tests/
│   └── test_health.py
├── .env.example
├── alembic.ini
├── pyproject.toml
└── README.md
```

## What's deliberately NOT here yet

Authentication, users, learner profiles, subjects, assessments,
adaptive quiz logic, the knowledge graph, learning paths,
recommendations, the AI tutor, OpenAI integration, video processing,
analytics, gamification, and billing are all out of scope for this
foundation layer. They're built incrementally in later tasks, each on
top of what's already here.
