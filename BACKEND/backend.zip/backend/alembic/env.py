"""Alembic environment configuration.

This wires Alembic to the application's own configuration
(app.core.config.get_settings) and declarative base (app.db.base.Base),
so DATABASE_URL only has to be defined in one place (.env), and future
models registered on Base are automatically picked up for autogenerate.

No models exist yet, so `target_metadata` is currently empty — that's
expected. Do not run `alembic revision --autogenerate` until
application models have been added in a later task.
"""

import sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

# Make the `app` package importable when Alembic is run from the
# backend/ directory.
sys.path.append(str(Path(__file__).resolve().parents[1]))

from app.core.config import get_settings  # noqa: E402
from app.db.base import Base  # noqa: E402

# Alembic Config object, providing access to values in alembic.ini
config = context.config

# Interpret the config file for Python logging.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Target metadata for 'autogenerate' support. Empty until models exist.
target_metadata = Base.metadata

settings = get_settings()
if not settings.database_url:
    raise RuntimeError(
        "DATABASE_URL is not set. Configure it in your .env file before "
        "running Alembic (see .env.example)."
    )

# Override the sqlalchemy.url from alembic.ini with the application's
# own DATABASE_URL, so there is one source of truth for the connection
# string.
config.set_main_option("sqlalchemy.url", settings.database_url)


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode (generates SQL, no DB connection)."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode (connects to the database)."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
