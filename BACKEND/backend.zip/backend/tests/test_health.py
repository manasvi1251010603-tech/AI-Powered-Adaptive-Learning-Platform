"""Tests for the foundation layer: app import and the health endpoint.

Deliberately does not test /ready against a real database — that would
make the test suite depend on a running PostgreSQL instance. /ready is
exercised manually (see README.md) and will get proper test coverage
(with a test database or a mocked connection) once the database layer
has real models to test against.
"""

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_app_initializes_without_importing_future_feature_modules() -> None:
    """The app object must import and construct cleanly.

    This module only imports app.main, which only imports the
    foundation-layer modules (core/, db/, api/router.py). If a future
    change accidentally imports an unbuilt feature module at startup,
    this import would fail loudly here.
    """
    assert app.title == "AI-Powered Adaptive Learning Platform API"


def test_health_returns_200_and_status_ok() -> None:
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_ready_returns_a_dependencies_object() -> None:
    """/ready should always report a structured dependency status.

    Status code varies with whether DATABASE_URL is configured/reachable
    in the environment running the tests, so this only asserts on
    response shape, not on a specific "ready" outcome.
    """
    response = client.get("/ready")

    assert response.status_code in (200, 503)
    body = response.json()
    assert body["status"] in ("ready", "not_ready")
    assert "database" in body["dependencies"]
    assert body["dependencies"]["database"] in ("ok", "error", "not_configured")
