"""Versioned API router.

This router is mounted at /api/v1 in app/main.py. It intentionally has
no routes yet — feature modules (auth, assessments, knowledge-graph,
...) will register their own routers here in later tasks, e.g.:

    from app.modules.auth.router import router as auth_router
    api_router.include_router(auth_router, prefix="/auth", tags=["auth"])

Health/readiness endpoints (GET /health, GET /ready) are intentionally
NOT under /api/v1 — they live at the application root in app/main.py,
which is the conventional place for infrastructure/load-balancer
health checks.
"""

from fastapi import APIRouter

api_router = APIRouter()
