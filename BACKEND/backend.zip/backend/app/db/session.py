"""Database engine and session factory.

Uses synchronous SQLAlchemy 2.x with the `psycopg` (v3) driver. Sync
was chosen over async SQLAlchemy for this foundation layer to keep the
first runnable version of the backend as simple as possible for a
first-time full-stack developer — FastAPI already runs sync path
functions in a threadpool, so this does not block the event loop.
Async SQLAlchemy can be introduced later if a specific feature
(e.g. high-concurrency streaming) needs it; that would be a deliberate,
documented change to this file and to TECH_STACK.md, not a default.

DATABASE_URL is expected in the form:

    postgresql+psycopg://<user>:<password>@<host>:<port>/<database>

No engine/session is created if DATABASE_URL is not configured, so the
app can still start (e.g. to hit GET /health) without a database —
GET /ready will correctly report the database as unavailable in that
case.
"""

from collections.abc import Generator

from sqlalchemy import Engine, create_engine, text
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import get_settings

settings = get_settings()

engine: Engine | None = (
    create_engine(settings.database_url, pool_pre_ping=True)
    if settings.database_url
    else None
)

SessionLocal: sessionmaker[Session] | None = (
    sessionmaker(bind=engine, autocommit=False, autoflush=False, expire_on_commit=False)
    if engine is not None
    else None
)


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a database session per request.

    Not used by any endpoint yet in this foundation layer — it exists
    so future feature modules can depend on it (`db: Session =
    Depends(get_db)`) without re-implementing session handling.
    """
    if SessionLocal is None:
        raise RuntimeError(
            "DATABASE_URL is not configured. Set it in your .env file."
        )
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def check_database_connection() -> str:
    """Check whether the database is reachable, for GET /ready.

    Returns one of: "ok", "error", "not_configured".
    """
    if engine is None:
        return "not_configured"
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        return "ok"
    except Exception:
        return "error"
