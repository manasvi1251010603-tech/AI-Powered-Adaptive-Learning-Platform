"""SQLAlchemy declarative base.

Every future application model (User, Concept, Assessment, ...) will
inherit from `Base`. No models are defined here — this foundation layer
intentionally creates no application tables (see DATABASE_SCHEMA.md,
implemented in later tasks).
"""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Shared declarative base class for all ORM models."""
