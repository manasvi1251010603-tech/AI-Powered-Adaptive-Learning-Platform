"""Basic application logging configuration.

Deliberately simple: one stream handler writing to stdout with a
consistent text format, and a log level driven by configuration. This
is enough to get useful, readable logs locally and in a container
platform's log viewer. A full observability stack (structured JSON
logs shipped to a log aggregator, distributed tracing, etc.) is a
later concern, not part of this foundation.
"""

import logging
import sys

from app.core.config import get_settings

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
_DATE_FORMAT = "%Y-%m-%dT%H:%M:%S%z"


def configure_logging() -> None:
    """Configure the root logger. Safe to call once at app startup."""
    settings = get_settings()
    level = getattr(logging, settings.log_level.upper(), logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(fmt=_LOG_FORMAT, datefmt=_DATE_FORMAT))

    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.addHandler(handler)
    root_logger.setLevel(level)

    # Keep noisy third-party loggers at a sane level rather than silencing
    # them entirely — useful for debugging request handling during dev.
    logging.getLogger("uvicorn.error").setLevel(level)
    logging.getLogger("uvicorn.access").setLevel(level)
