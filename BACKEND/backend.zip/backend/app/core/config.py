"""Typed application configuration.

All configuration is read from environment variables (optionally via a
local .env file during development). Nothing in this module should ever
contain a real secret — see .env.example for the variables this project
expects.

Only DATABASE_URL is actually used by this foundation layer. The other
variables (REDIS_URL, JWT_SECRET_KEY, OPENAI_API_KEY, STORAGE_*) are
declared now so the typed config surface exists, but they are not yet
read or acted on anywhere in the app — they belong to features that
will be implemented in later tasks (auth, AI, storage).
"""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings, populated from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- General ---
    environment: str = Field(default="development", alias="ENVIRONMENT")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # --- CORS ---
    # Comma-separated list of allowed frontend origins, e.g.
    # "http://localhost:3000,https://app.example.com"
    backend_cors_origins: str = Field(
        default="http://localhost:3000",
        alias="BACKEND_CORS_ORIGINS",
    )

    # --- Database (used by this foundation layer) ---
    database_url: str | None = Field(default=None, alias="DATABASE_URL")

    # --- Reserved for later tasks (declared, not yet used) ---
    redis_url: str | None = Field(default=None, alias="REDIS_URL")
    jwt_secret_key: str | None = Field(default=None, alias="JWT_SECRET_KEY")
    openai_api_key: str | None = Field(default=None, alias="OPENAI_API_KEY")
    storage_endpoint: str | None = Field(default=None, alias="STORAGE_ENDPOINT")
    storage_bucket: str | None = Field(default=None, alias="STORAGE_BUCKET")
    storage_access_key: str | None = Field(default=None, alias="STORAGE_ACCESS_KEY")
    storage_secret_key: str | None = Field(default=None, alias="STORAGE_SECRET_KEY")
    storage_region: str | None = Field(default=None, alias="STORAGE_REGION")

    @property
    def cors_origins_list(self) -> list[str]:
        """The configured CORS origins as a clean list."""
        return [
            origin.strip()
            for origin in self.backend_cors_origins.split(",")
            if origin.strip()
        ]

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    """Return a cached Settings instance.

    Cached so the environment is only parsed once per process, while
    still being easy to override in tests via dependency overrides or
    by clearing the cache (get_settings.cache_clear()).
    """
    return Settings()
